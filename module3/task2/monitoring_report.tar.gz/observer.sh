#!/bin/bash

CONFIG_FILE="practice2/observer.conf"
OBSERVER_LOG="practice2/observer.log"
SCRIPTS_DIR="practice2" 

if [ ! -f "$CONFIG_FILE" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Ошибка: файл конфигурации $CONFIG_FILE не найден" >> "$OBSERVER_LOG"
    exit 1
fi

while IFS= read -r script_name; do
    # Пропуск пустых строк и комментариев
    if [[ -z "$script_name" || "$script_name" =~ ^[[:space:]]*# ]]; then
        continue
    fi

    script_name=$(echo "$script_name" | xargs)

    full_script_path="$SCRIPTS_DIR/$script_name"  # Добавляем путь

    if [ ! -f "$full_script_path" ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Ошибка: скрипт $full_script_path не найден" >> "$OBSERVER_LOG"
        continue
    fi

    if pgrep -f "$script_name" > /dev/null; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Скрипт $script_name уже выполняется" >> "$OBSERVER_LOG"
    else
        nohup "$full_script_path" > /dev/null 2>&1 &  # Используем полный путь
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Скрипт $script_name перезапущен (PID: $!)" >> "$OBSERVER_LOG"
    fi
done < "$CONFIG_FILE"
